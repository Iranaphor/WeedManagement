^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map_pcl
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.6.0 (2017-11-24)
------------------

1.5.2 (2017-07-25)
------------------

1.5.1 (2017-07-25)
------------------

1.5.0 (2017-07-18)
------------------
* Improved efficiency of mesh conversion.
* Contributors: Alex Millane

1.4.2 (2017-01-24)
------------------
* Addressing C++ compiler warnings.
* Contributors: Peter Fankhauser

1.4.1 (2016-10-23)
------------------
* Added new grid_map_pcl package to convert from PCL mesh to grid map.
* Contributors: Dominic Jud
