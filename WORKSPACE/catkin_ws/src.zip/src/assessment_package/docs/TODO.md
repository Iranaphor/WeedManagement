## TODO:

:D - Swap out Thorvald_001 launch file names  
Branch Opened: - Fix the sprayer alignment and spraying bugs  
:D - Rename the killbox  
:D - Convert KILLER to CONFIG  
:D - Write README.md (100 word limit)  
:D - Copy movebase stuffs to assessment_package  
Test package.xml on fresh ubuntu system
Remove unneccessary comments/printouts  
Rename Package  
:D - Remove extra .msg  
:D - Remove map folder  
:D - Comment /launch  
:D - Clean /launch  
:D - Comment /scripts  
:D - Comment /config  
:D - Comment /msg  
:D - Clean /msg  
:D - Comment /scripts/image_processing  
:D - Clean /scripts/image_processing  
:D - Custom sized XML objects  
:D - Fix final crop_row marking
Replace `import cv2` with the rospack equivilant
